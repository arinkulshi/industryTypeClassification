# sec_header_cli.py
import argparse
import json
from pathlib import Path

from sec_client import SecClient
from sec_header import get_latest_header_info

def load_ticker_map(path: str) -> dict:
    j = json.loads(Path(path).read_text())
    return j.get("map", j)

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--user-agent", required=True, help="Real UA with contact info (SEC requirement)")
    p.add_argument("--cik", help="CIK (10-digit or int-like)")
    p.add_argument("--ticker", help="Ticker symbol (requires --ticker-json)")
    p.add_argument("--ticker-json", help="Path to ticker_map.json")
    args = p.parse_args()

    if not args.cik and not args.ticker:
        p.error("Provide --cik or --ticker (with --ticker-json).")

    cik = args.cik
    if args.ticker:
        if not args.ticker_json:
            p.error("--ticker-json is required when using --ticker.")
        tmap = load_ticker_map(args.ticker_json)
        t = args.ticker.upper()
        if t not in tmap:
            p.error(f"Ticker {t} not found in ticker map.")
        cik = tmap[t]

    client = SecClient(user_agent=args.user_agent)
    info = get_latest_header_info(client, cik)
    if info is None:
        print("No header info found.")
        return

    print(json.dumps(info, indent=2))

if __name__ == "__main__":
    main()
