import argparse
from pathlib import Path
from sec_index_loader import SecIndex, DEFAULT_UA

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--cache", required=True, help="Directory for JSON cache files")
    p.add_argument("--user-agent", default=DEFAULT_UA, help="HTTP User-Agent for SEC requests")
    sub = p.add_subparsers(dest="cmd", required=True)

    p_refresh = sub.add_parser("refresh", help="Refresh caches")
    p_refresh.add_argument("--use-master", action="store_true", help="Augment names using quarterly master.gz")
    p_refresh.add_argument("--years-back", type=int, default=5, help="How many recent years of master.gz to aggregate")
    p_refresh.add_argument("--force", action="store_true", help="Ignore TTL and refetch")

    p_check = sub.add_parser("check", help="Run acceptance checks")

    args = p.parse_args()
    sx = SecIndex(cache_dir=Path(args.cache), user_agent=args.user_agent)

    if args.cmd == "refresh":
        t, n = sx.refresh_json_cache(use_master=args.use_master, years_back=args.years_back, force=args.force)
        print(f"JSON caches written:\n - {t}\n - {n}")
        # Sanity warning
        _, name_map, _, _, count = sx.load_from_cache()
        if count <= 20000:
            print("WARNING: name_to_ciks has <= 20k keys. This likely means only ticker data was captured. "
                  "Ensure cik-lookup-data.txt fetched successfully and/or enable --use-master.")
    elif args.cmd == "check":
        ticker_map, name_map, ft, fn, count = sx.load_from_cache()
        ok_aapl = ("AAPL" in ticker_map) and (len(ticker_map["AAPL"]) == 10)
        apple_list = name_map.get("APPLE", [])
        print(f"Fetched at: tickers={ft} names={fn}")
        print(f"AAPL exists w/ zero-padded CIK? {'YES' if ok_aapl else 'NO'}")
        print(f"name_to_ciks size: {count:,}")
        print(f"'APPLE' CIKs present? {'YES' if len(apple_list)>0 else 'NO'}")
    else:
        p.print_help()

if __name__ == "__main__":
    main()