# Chunk 1 — Name Normalization
#
# This script:
# 1) Implements a deterministic company-name normalizer per the rules.
# 2) Loads your sample CSV from /mnt/data.
# 3) Detects the likely company-name column.
# 4) Adds a `normalized_name` column.
# 5) Writes a new CSV you can download.
# 6) Shows the normalized table in an interactive grid.
#
# Acceptance checks included at the bottom.

import re
import pandas as pd
from pathlib import Path
from io import StringIO

# ---------- Normalization ----------

# Corporate suffixes to remove (whole-word, trailing)
_SUFFIX_PATTERN = re.compile(
    r"""
    (?:\s+|^)                # leading space or start
    (?:                      # one of the common corporate suffixes
        CORPORATION|CORP|INCORPORATED|INC|LLC|L\.L\.C\.|LTD|LIMITED|PLC|CO|COMPANY|HOLDING|HOLDINGS
    )
    (?:\s+|$)                # trailing space or end
    """,
    re.IGNORECASE | re.VERBOSE,
)

_PUNCT_TO_SPACE = re.compile(r"[^A-Z0-9]+")  # replace any non-alnum with space (after uppercasing)


def normalize_company_name(s: str) -> str:
    """
    Rules (deterministic):
    - Uppercase.
    - Remove punctuation (convert non-alnum to spaces).
    - Strip corporate suffixes (whole-word): INC|INCORPORATED|LLC|L.L.C.|LTD|LIMITED|PLC|CO|COMPANY|CORP|CORPORATION|HOLDING(S).
    - Collapse whitespace to single spaces; trim ends.
    """
    if s is None:
        return ""
    # Uppercase first
    x = str(s).upper().strip()
    # Remove punctuation -> spaces
    x = _PUNCT_TO_SPACE.sub(" ", x)
    # Collapse whitespace
    x = re.sub(r"\s+", " ", x).strip()
    # Remove trailing corporate suffixes repeatedly (in case of multiples like "CO INC")
    prev = None
    while prev != x and x:
        prev = x
        # Remove a suffix at end; we add spaces around to ensure word boundaries
        x_sp = f" {x} "
        x_sp2 = _SUFFIX_PATTERN.sub(" ", x_sp)
        x = re.sub(r"\s+", " ", x_sp2).strip()
    return x


# ---------- Load your CSV & apply ----------

input_path = Path("/Users/arindamkulshi/industryTypeClassification/sec_cache/company_names.csv")

# Try reading with default; if that fails, fallback
try:
    df = pd.read_csv(input_path)
except Exception:
    df = pd.read_csv(input_path, engine="python")

# Heuristic to find the company-name column
cols = [c for c in df.columns]
name_candidates = [c for c in cols if re.search(r"(company|name)", c, re.IGNORECASE)]
company_col = name_candidates[0] if name_candidates else cols[0]

# Apply normalization
df["normalized_name"] = df[company_col].apply(normalize_company_name)

# Save result
output_path = Path("company_names_normalized.csv")
df.to_csv(output_path, index=False)


# ---------- Acceptance checks (quick) ----------

tests = {
    "The ACME Co., Inc.": "ACME",
    "Globex LLC": "GLOBEX",
    "  Foo-Bar Holdings,   Inc  ": "FOO BAR",
    "Initech Corporation": "INITECH",
    "Umbrella Company Ltd.": "UMBRELLA",
    "AT&T Inc": "AT T",  # punctuation removal collapses & to space per spec
}

results = {k: normalize_company_name(k) for k in tests}
results
