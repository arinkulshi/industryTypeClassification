# sic_cli.py
import argparse
import json
from pathlib import Path

import pandas as pd

from sec_client import SecClient
from sic_retrieval import SicResolver

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--user-agent", required=True, help="Real UA with contact info")
    p.add_argument("--cik", help="Single CIK (10-digit or int-like)")
    p.add_argument("--in", dest="inp", help="Input CSV with a 'cik10' column (e.g., from resolve_cli)")
    p.add_argument("--out", default="with_sic.csv", help="Output CSV when using --in")
    p.add_argument("--cache-dir", default="./sec_cache", help="Directory for the SIC cache")
    args = p.parse_args()

    client = SecClient(user_agent=args.user_agent)
    sicr = SicResolver(client, cache_dir=args.cache_dir, ttl_hours=24)

    # Single CIK mode
    if args.cik:
        info = sicr.get_sic(args.cik)
        print(json.dumps(info or {"sic": None, "sicDescription": None}, indent=2))
        return

    # Batch mode
    if args.inp:
        df = pd.read_csv(args.inp, dtype=str)
        if "cik10" not in df.columns:
            raise SystemExit("Input CSV must contain a 'cik10' column.")
        sic_vals, desc_vals, src_vals = [], [], []
        for cik in (df["cik10"].fillna("").astype(str)):
            if not cik.strip():
                sic_vals.append(None); desc_vals.append(None); src_vals.append(None); continue
            info = sicr.get_sic(cik)
            sic_vals.append(info.get("sic") if info else None)
            desc_vals.append(info.get("sicDescription") if info else None)
            src_vals.append(info.get("source") if info else None)
        df["sic"] = sic_vals
        df["sic_description"] = desc_vals
        df["industry_subtype"] = df["sic_description"]  # your single label output
        df["sic_source"] = src_vals
        df.to_csv(args.out, index=False)
        print(f"Wrote {args.out}  (rows: {len(df)})")
        return

    p.print_help()

if __name__ == "__main__":
    main()
