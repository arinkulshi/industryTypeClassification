#You can run this as a test

# Fix import path for the just-written module and rerun the synthetic demo.
import sys
from pathlib import Path

import pandas as pd
from candidate_generation import generate_candidates

# Synthetic name_to_ciks map to demonstrate acceptance checks
demo_map = {
    "APPLE": ["0000320193"],
    "MICROSOFT": ["0000789019"],
    "ALPHABET": ["0001652044"],
    "MICROSOFT CORPORATION": ["0000789019"],
    "MICRO SOFT": ["0000789019"],
}

tests = [
    "APPLE",           # exact
    "MICRO SOFT",     # fuzzy should catch MICROSOFT
    "APP LE",         # fuzzy against APPLE
    "ZZZQ QQQQ",      # no result
]

rows = []
for q in tests:
    cands = generate_candidates(q, demo_map, threshold=0.85, limit=10)
    rows.append({
        "query": q,
        "candidates": [{"cik10": c.cik10, "edgar_name": c.edgar_name, "name_score": round(c.name_score, 4)} for c in cands]
    })

print(rows)