# candidate_generation.py (patched)
from __future__ import annotations
import re
from dataclasses import dataclass
from difflib import SequenceMatcher
from typing import Dict, List, Iterable, Tuple, Optional, Set

STOPWORDS = {"THE", "A", "AN"}
_WORD_SPLIT = re.compile(r"\s+")
_NON_ALNUM = re.compile(r"[^A-Z0-9 ]+")

def _norm(s: str) -> str:
    s = (s or "").upper()
    s = _NON_ALNUM.sub(" ", s)
    return _WORD_SPLIT.sub(" ", s).strip()

def token_set_ratio(a: str, b: str) -> float:
    a = _norm(a)
    b = _norm(b)
    if not a or not b:
        return 0.0
    a_tokens = set(a.split())
    b_tokens = set(b.split())
    inter = " ".join(sorted(a_tokens & b_tokens))
    a_rem = " ".join(sorted(a_tokens - b_tokens))
    b_rem = " ".join(sorted(b_tokens - a_tokens))
    score1 = SequenceMatcher(None, inter, (inter + " " + a_rem).strip()).ratio()
    score2 = SequenceMatcher(None, inter, (inter + " " + b_rem).strip()).ratio()
    return max(score1, score2)

@dataclass
class Candidate:
    cik10: str
    edgar_name: str
    name_score: float

class NameIndex:
    def __init__(self, name_to_ciks: Dict[str, List[str]]):
        self.name_to_ciks = name_to_ciks
        self._buckets: Dict[Tuple[str,int], List[str]] = {}
        self._token_to_names: Dict[str, Set[str]] = {}
        self._build()

    @staticmethod
    def _first_bucket_key(name_norm: str) -> str:
        first = name_norm[:1] if name_norm else ""
        return first if first.isalpha() else "#"

    @staticmethod
    def _len_band(name_norm: str) -> int:
        return len(name_norm) // 5

    def _build(self):
        for name_norm in self.name_to_ciks.keys():
            key = (self._first_bucket_key(name_norm), self._len_band(name_norm))
            self._buckets.setdefault(key, []).append(name_norm)
            for tok in name_norm.split():
                if len(tok) >= 3 and tok not in STOPWORDS:
                    self._token_to_names.setdefault(tok, set()).add(name_norm)

    def _candidate_names_for_query(self, query: str) -> Iterable[str]:
        q = query
        fk = self._first_bucket_key(q)
        lb = self._len_band(q)
        seen: Set[str] = set()

        # 1) primary buckets: same first letter, len band ±1
        for band in (lb-1, lb, lb+1):
            key = (fk, band)
            for nm in self._buckets.get(key, []):
                if nm not in seen:
                    seen.add(nm); yield nm

        # 2) token hits: allow len band ±3 (less strict), then fallback no band if still empty
        toks = [t for t in q.split() if len(t) >= 3 and t not in STOPWORDS]
        hit_any = False
        for t in toks:
            for nm in self._token_to_names.get(t, ()):
                if abs(self._len_band(nm) - lb) <= 3 and nm not in seen:
                    seen.add(nm); hit_any = True; yield nm
        if not hit_any:
            # last resort: any token hit (cap yielded names implicitly via final similarity & limit)
            for t in toks:
                for nm in self._token_to_names.get(t, ()):
                    if nm not in seen:
                        seen.add(nm); yield nm

    def exact_match(self, query: str) -> Optional[List[Candidate]]:
        if query in self.name_to_ciks:
            return [Candidate(c, query, 1.0) for c in self.name_to_ciks[query]]
        return None

    def fuzzy_candidates(self, query: str, threshold: float = 0.85, limit: int = 10) -> List[Candidate]:
        results: List[Candidate] = []
        seen_pairs: Set[Tuple[str,str]] = set()
        for name_norm in self._candidate_names_for_query(query):
            score = token_set_ratio(query, name_norm)
            if score >= threshold:
                for cik in self.name_to_ciks.get(name_norm, []):
                    key = (cik, name_norm)
                    if key not in seen_pairs:
                        seen_pairs.add(key)
                        results.append(Candidate(cik10=cik, edgar_name=name_norm, name_score=score))
        results.sort(key=lambda c: (-c.name_score, c.edgar_name, c.cik10))
        return results[:limit]

def generate_candidates(normalized_name: str, name_to_ciks: Dict[str, List[str]], threshold: float = 0.85, limit: int = 10) -> List[Candidate]:
    idx = NameIndex(name_to_ciks)
    exact = idx.exact_match(normalized_name)
    if exact:
        return exact[:limit]
    return idx.fuzzy_candidates(normalized_name, threshold=threshold, limit=limit)
