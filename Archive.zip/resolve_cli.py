# resolve_cli.py
import argparse
import json
import re
from pathlib import Path

import pandas as pd

from sec_client import SecClient
from candidate_generation import generate_candidates
from scoring import rank_candidates
from resolution import resolve_cik

# Reuse flexible column detection from the improved score_cli
def _find_col(cols, patterns):
    lower = {c.lower(): c for c in cols}
    for pat in patterns:
        rx = re.compile(pat, re.I)
        for lc, orig in lower.items():
            if rx.fullmatch(lc) or rx.search(lc):
                return orig
    return None

def _pick_columns(df, name_col, city_col, zip_col):
    cols = list(df.columns)
    if not name_col:
        name_col = _find_col(cols, [r"^normalized_name$", r"^company(\s*name)?$", r"^name$"])
    if not city_col:
        city_col = _find_col(cols, [r"^city$"])
    if not zip_col:
        zip_col = _find_col(cols, [r"^zip$", r"^zip[_\s-]?code$", r"^postal[_\s-]?code$", r"^postal$"])
    return name_col, city_col, zip_col

def load_name_map(path: str) -> dict:
    j = json.loads(Path(path).read_text())
    return j.get("map", j)

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--user-agent", required=True)
    p.add_argument("--names-json", required=True)

    # Single row
    p.add_argument("--name")
    p.add_argument("--city")
    p.add_argument("--zip5")

    # Batch
    p.add_argument("--csv")
    p.add_argument("--name-col")
    p.add_argument("--city-col")
    p.add_argument("--zip-col")
    p.add_argument("--out", default="resolved.csv")
    p.add_argument("--audit", default=None, help="Optional JSONL with ranked candidates for each row")

    # knobs
    p.add_argument("--threshold", type=float, default=0.85)
    p.add_argument("--limit", type=int, default=10)
    p.add_argument("--min-accept", type=float, default=1.6)
    p.add_argument("--gap-accept", type=float, default=0.3)

    args = p.parse_args()
    name_map = load_name_map(args.names_json)
    client = SecClient(user_agent=args.user_agent)

    # Single row path
    if args.name:
        if not (args.city and args.zip5):
            p.error("Provide --city and --zip5 for single row mode.")
        cands = generate_candidates(args.name, name_map, threshold=args.threshold, limit=args.limit)
        ranked = rank_candidates(cands, args.city, args.zip5, client=client, limit=args.limit)
        final = resolve_cik(ranked, args.zip5, min_accept=args.min_accept, gap_accept=args.gap_accept, keep_top=3)
        print(json.dumps({"query": {"name": args.name, "city": args.city, "zip5": args.zip5}, **final}, indent=2))
        return

    # Batch path
    if args.csv:
        df = pd.read_csv(args.csv, dtype=str)
        name_col, city_col, zip_col = _pick_columns(df, args.name_col, args.city_col, args.zip_col)
        if not all([name_col, city_col, zip_col]):
            missing = []
            if not name_col: missing.append("name")
            if not city_col: missing.append("city")
            if not zip_col:  missing.append("zip")
            p.error(f"CSV missing required column(s): {', '.join(missing)}. "
                    f"Use --name-col/--city-col/--zip-col to specify their names.")

        rows = []
        audit_f = open(args.audit, "w") if args.audit else None
        for _, r in df.iterrows():
            name = (r[name_col] or "").strip()
            city = (r[city_col] or "").strip()
            zip5 = (r[zip_col] or "").strip()[:5]
            if not name or not city or not zip5:
                rows.append({"name": name, "city": city, "zip5": zip5, "status": "not_found", "reason": "missing inputs"})
                continue

            cands = generate_candidates(name, name_map, threshold=args.threshold, limit=args.limit)
            ranked = rank_candidates(cands, city, zip5, client=client, limit=args.limit)
            final = resolve_cik(ranked, zip5, min_accept=args.min_accept, gap_accept=args.gap_accept, keep_top=3)

            if audit_f:
                audit_f.write(json.dumps({"query": {"name": name, "city": city, "zip5": zip5}, "ranked": ranked, "final": final}) + "\n")

            rows.append({
                "name": name, "city": city, "zip5": zip5,
                "status": final["status"],
                "cik10": final.get("cik10", ""),
                "reason": final.get("reason", ""),
            })
        if audit_f:
            audit_f.close()

        out_df = pd.DataFrame(rows)
        out_df.to_csv(args.out, index=False)
        print(f"Wrote {args.out}  (rows: {len(out_df)})")
        if args.audit:
            print(f"Wrote audit JSONL: {args.audit}")
        return

    p.print_help()

if __name__ == "__main__":
    main()
