# sec_header.py (patched extractors)
from __future__ import annotations
import random, re, time
from typing import Dict, List, Optional, Tuple
import requests
from sec_client import SecClient, SecHttpError

_PRIOR_FORMS = ("10-K", "20-F")

def _pick_latest_index(submissions: Dict) -> Optional[int]:
    recent = (submissions or {}).get("filings", {}).get("recent", {})
    forms = recent.get("form") or []
    dates = recent.get("filingDate") or []
    if not forms:
        return None
    idxs = list(range(len(forms)))
    idxs.sort(key=lambda i: (dates[i] or ""), reverse=True)
    for i in idxs:
        if forms[i] in _PRIOR_FORMS:
            return i
    return idxs[0] if idxs else None

def _accession_arrays(submissions: Dict) -> Tuple[List[str], List[str], List[str]]:
    recent = (submissions or {}).get("filings", {}).get("recent", {})
    return (recent.get("accessionNumber") or [], recent.get("form") or [], recent.get("filingDate") or [])

def _acc_to_url(cik10: str, accession: str) -> str:
    acc_nodash = accession.replace("-", "")
    return f"https://www.sec.gov/Archives/edgar/data/{int(cik10)}/{acc_nodash}/{accession}.hdr.sgml"

def _sleep_backoff(attempt: int, retry_after: Optional[str] = None):
    if retry_after:
        try:
            secs = float(retry_after)
            time.sleep(min(max(secs, 0.5), 10.0)); return
        except: pass
    base = 0.5 * (2 ** (attempt - 1))
    time.sleep(min(base + random.uniform(0.0, 0.3), 5.0))

def _fetch_header_text(client: SecClient, url: str, max_tries: int = 3, timeout: int = 60) -> Optional[str]:
    for attempt in range(1, max_tries + 1):
        client._bucket.acquire(1.0)
        try:
            r = client.session.get(url, timeout=timeout)
        except requests.RequestException as e:
            if attempt >= max_tries: raise SecHttpError(-1, url, f"Network error: {e}")
            _sleep_backoff(attempt); continue
        if r.status_code == 404: return None
        if 200 <= r.status_code < 300: return r.text
        if r.status_code in (429, 500, 502, 503, 504):
            if attempt >= max_tries: raise SecHttpError(r.status_code, url, r.text[:500])
            _sleep_backoff(attempt, r.headers.get("Retry-After")); continue
        raise SecHttpError(r.status_code, url, r.text[:500])
    raise SecHttpError(-1, url, "Exhausted retries")

# --- parsing improvements ---
_FIELD_PATTERNS = {
    "CITY": [r"^CITY:\s*(.+?)\s*$"],
    "STATE":[r"^STATE:\s*([A-Z]{2})\s*$"],
    "ZIP":  [
        r"^ZIP:\s*(.+?)\s*$",
        r"^ZIP\s*CODE:\s*(.+?)\s*$",
        r"^ZIP/POSTAL\s*CODE:\s*(.+?)\s*$",
        r"^POSTAL\s*CODE:\s*(.+?)\s*$",
    ],
}
def _extract_field(window: str, label: str) -> Optional[str]:
    for pat in _FIELD_PATTERNS.get(label, []):
        m = re.search(pat, window, flags=re.IGNORECASE|re.MULTILINE)
        if m: return m.group(1).strip().upper()
    return None

def _parse_addresses(text: str) -> Dict[str, Dict[str, str]]:
    out = {"business": {}, "mail": {}}
    if not text: return out
    for label_key, label_out in (("BUSINESS","business"), ("MAIL","mail")):
        m = re.search(rf"(?im)^{label_key}\s+ADDRESS:\s*$", text)
        if not m: continue
        start = m.end()
        window = text[start:start+3000]  # wider window
        city  = _extract_field(window, "CITY")
        state = _extract_field(window, "STATE")
        zipln = _extract_field(window, "ZIP")
        zip5 = None
        if zipln:
            mzip = re.search(r"\b(\d{5})\b", zipln)
            if mzip: zip5 = mzip.group(1)
        block = {}
        if city:  block["city"] = city
        if state: block["state"] = state[:2].upper()
        if zip5:  block["zip5"] = zip5
        out[label_out] = block if block else {}
    return out

def get_latest_header_info(client: SecClient, cik: str | int) -> Optional[Dict]:
    subs = client.get_submissions(cik)
    if not subs: return None
    idx = _pick_latest_index(subs)
    if idx is None: return None
    accessions, forms, dates = _accession_arrays(subs)
    accession = accessions[idx]; form = forms[idx]; filing_date = dates[idx] if idx < len(dates) else None
    cik10 = f"{int(str(subs.get('cik') or cik)):010d}"
    url = _acc_to_url(cik10, accession)
    text = _fetch_header_text(client, url)
    if not text: return None
    addrs = _parse_addresses(text)
    return {
        "cik10": cik10, "accession": accession, "form": form, "filingDate": filing_date,
        "header_url": url, "addresses": addrs,
    }
