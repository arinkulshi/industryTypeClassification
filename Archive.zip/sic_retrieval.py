# sic_retrieval.py
from __future__ import annotations
import json
from pathlib import Path
from typing import Optional, Dict, Any
from datetime import datetime, timedelta, timezone

from sec_client import SecClient

def _now_utc_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

def _is_fresh(ts: str, ttl_hours: int) -> bool:
    try:
        dt = datetime.fromisoformat(ts)
    except Exception:
        return False
    return (datetime.now(timezone.utc) - dt) < timedelta(hours=ttl_hours)

def _fmt_sic_value(raw: Any) -> Optional[str]:
    # Return a 4-digit SIC string when possible; else None.
    if raw is None:
        return None
    try:
        n = int(str(raw).strip())
        if 0 <= n <= 9999:
            return f"{n:04d}"
    except Exception:
        pass
    return None

class SicResolver:
    """
    Fetches SIC & sicDescription via Submissions JSON:
      https://data.sec.gov/submissions/CIK##########.json

    - Uses a small on-disk cache (per-entity) under `cache_dir/sic_cache.json`
    - Returns: { 'sic': '####'|None, 'sicDescription': str|None, 'source': 'submissions'|'cache' }
    """
    def __init__(self, client: SecClient, cache_dir: str = "./sec_cache", ttl_hours: int = 24):
        self.client = client
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.cache_file = self.cache_dir / "sic_cache.json"
        self.ttl_hours = int(ttl_hours)
        # load cache
        if self.cache_file.exists():
            try:
                self._cache = json.loads(self.cache_file.read_text())
            except Exception:
                self._cache = {"fetched_at": _now_utc_iso(), "map": {}}
        else:
            self._cache = {"fetched_at": _now_utc_iso(), "map": {}}

    def _save(self):
        self._cache["fetched_at"] = _now_utc_iso()
        self.cache_file.write_text(json.dumps(self._cache, indent=2))

    def get_sic(self, cik: str | int) -> Optional[Dict[str, Any]]:
        # normalize CIK to 10 digits like SecClient does
        try:
            cik10 = f"{int(str(cik).strip()):010d}"
        except Exception:
            return None

        # cache hit?
        entry = (self._cache.get("map") or {}).get(cik10)
        if entry and _is_fresh(entry.get("ts", ""), self.ttl_hours):
            return {"sic": entry.get("sic"), "sicDescription": entry.get("sicDescription"), "source": "cache"}

        # fetch submissions
        sub = self.client.get_submissions(cik10)
        if not sub:
            # cache a miss with short TTL to avoid hammering
            self._cache.setdefault("map", {})[cik10] = {"sic": None, "sicDescription": None, "ts": _now_utc_iso()}
            self._save()
            return None

        sic = _fmt_sic_value(sub.get("sic"))
        desc = sub.get("sicDescription") or None
        # Persist
        self._cache.setdefault("map", {})[cik10] = {"sic": sic, "sicDescription": desc, "ts": _now_utc_iso()}
        self._save()

        return {"sic": sic, "sicDescription": desc, "source": "submissions"}
