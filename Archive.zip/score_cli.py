# score_cli.py
import argparse
import json
import re
from pathlib import Path

import pandas as pd

from sec_client import SecClient
from candidate_generation import generate_candidates
from scoring import rank_candidates

# Try to reuse the same normalizer as Chunk 1/2; fallback if missing
try:
    from sec_normalize import normalize_company_name as _norm_name
except Exception:
    import re
    _SUFFIX = re.compile(r"(?:\s+|^)(?:CORPORATION|CORP|INCORPORATED|INC|LLC|L\.L\.C\.|LTD|LIMITED|PLC|CO|COMPANY|HOLDING|HOLDINGS)(?:\s+|$)", re.I)
    _PUNCT  = re.compile(r"[^A-Z0-9]+")
    def _norm_name(s: str) -> str:
        s = (s or "").upper().strip()
        s = _PUNCT.sub(" ", s)
        s = re.sub(r"\s+", " ", s).strip()
        prev = None
        while prev != s and s:
            prev = s
            s = " " + s + " "
            s = _SUFFIX.sub(" ", s)
            s = re.sub(r"\s+", " ", s).strip()
        return s

def load_name_map(path: str) -> dict:
    j = json.loads(Path(path).read_text())
    return j.get("map", j)

def _find_col(cols, patterns):
    """Case-insensitive column finder by regex list; returns actual col name or None."""
    lower = {c.lower(): c for c in cols}
    for pat in patterns:
        rx = re.compile(pat, re.I)
        for lc, orig in lower.items():
            if rx.fullmatch(lc) or rx.search(lc):
                return orig
    return None

def _pick_columns(df, name_col, city_col, zip_col):
    cols = list(df.columns)
    # name column
    if not name_col:
        # prefer 'normalized_name' exact-ish
        name_col = _find_col(cols, [r"^normalized_name$"])
        if not name_col:
            # fall back to anything like 'company' or 'name'
            name_col = _find_col(cols, [r"^company(\s*name)?$", r"^name$"])
    # city column
    if not city_col:
        city_col = _find_col(cols, [r"^city$"])
    # zip column
    if not zip_col:
        zip_col = _find_col(cols, [r"^zip$", r"^zip[_\s-]?code$", r"^postal[_\s-]?code$", r"^postal$"])
    return name_col, city_col, zip_col

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--user-agent", required=True)
    p.add_argument("--names-json", required=True, help="Chunk 2 name_to_ciks.json")
    p.add_argument("--name", help="Single normalized company name")
    p.add_argument("--city", help="City for single query")
    p.add_argument("--zip5", help="ZIP(5) for single query")
    p.add_argument("--csv", help="CSV for batch mode")
    p.add_argument("--out", default="ranked.jsonl", help="Output JSONL for batch mode")
    p.add_argument("--threshold", type=float, default=0.85, help="Fuzzy threshold for candidate gen")
    p.add_argument("--limit", type=int, default=10, help="Max candidates to return/score")
    # New: flexible column mapping for batch mode
    p.add_argument("--name-col", help="Column for company name (normalized or raw)")
    p.add_argument("--city-col", help="Column for city")
    p.add_argument("--zip-col", help="Column for zip / postal code")
    args = p.parse_args()

    # Single-query path stays the same
    name_map = load_name_map(args.names_json)
    client = SecClient(user_agent=args.user_agent)

    if args.name:
        if args.city is None or args.zip5 is None:
            p.error("For single query, provide --city and --zip5.")
        cands = generate_candidates(args.name, name_map, threshold=args.threshold, limit=args.limit)
        ranked = rank_candidates(cands, args.city, args.zip5, client=client, limit=args.limit)
        print(json.dumps({"query": args.name, "results": ranked}, indent=2))
        return

    # Batch mode
    if args.csv:
        df = pd.read_csv(args.csv, dtype=str)  # read all as str so ZIP leading zeros are preserved
        name_col, city_col, zip_col = _pick_columns(df, args.name_col, args.city_col, args.zip_col)

        if not city_col or not zip_col:
            missing = []
            if not city_col: missing.append("city")
            if not zip_col:  missing.append("zip")
            p.error(f"CSV is missing required column(s): {', '.join(missing)}. "
                    f"Use --city-col/--zip-col to specify their names.")

        if not name_col:
            p.error("CSV is missing a company name column. Provide --name-col (e.g., 'normalized_name' or 'Company').")

        # Prepare normalized name column
        norm_series = df[name_col].astype(str).fillna("").map(_norm_name)
        have_norm = _find_col(df.columns, [r"^normalized_name$"])
        if have_norm:
            # If they already had normalized_name but name_col is a raw name, prefer the provided column explicitly
            df["__normalized_name"] = df[name_col].astype(str).fillna("")
            if name_col != have_norm:
                # ensure we pass normalized string to candidate search
                df["__normalized_name"] = norm_series
        else:
            df["__normalized_name"] = norm_series

        total = len(df)
        processed = 0
        skipped = 0

        with open(args.out, "w") as f:
            for _, row in df.iterrows():
                name = (row["__normalized_name"] or "").strip()
                city = (row[city_col] or "").strip()
                zip5 = (row[zip_col] or "").strip()
                zip5 = zip5[:5] if zip5 else ""

                if not name or not city or not zip5:
                    skipped += 1
                    continue

                cands = generate_candidates(name, name_map, threshold=args.threshold, limit=args.limit)
                ranked = rank_candidates(cands, city, zip5, client=client, limit=args.limit)
                f.write(json.dumps({"query": {"name": name, "city": city, "zip5": zip5}, "results": ranked}) + "\n")
                processed += 1

        print(f"Input rows: {total}  |  processed: {processed}  |  skipped (missing fields): {skipped}")
        print(f"Wrote {args.out}")
        return

    p.print_help()

if __name__ == "__main__":
    main()
