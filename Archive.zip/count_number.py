import json

# Load JSON file
with open("/Users/arindamkulshi/industryTypeClassification/sec_cache/name_to_ciks.json", "r") as f:
    data = json.load(f)

# Count companies
num_companies = len(data["map"])

print(f"Total number of companies: {num_companies}")