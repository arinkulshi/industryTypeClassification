
import gzip
import io
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List, Iterable

import requests

from sec_normalize import normalize_company_name

DEFAULT_UA = "YourOrgName your.email@yourorg.com"
SEC_BASE = "https://www.sec.gov"
URL_COMPANY_TICKERS   = f"{SEC_BASE}/files/company_tickers.json"
URL_CIK_NAME_TXT      = f"{SEC_BASE}/Archives/edgar/cik-lookup-data.txt"
URL_MASTER_INDEX_TPL  = f"{SEC_BASE}/Archives/edgar/full-index/{{year}}/QTR{{q}}/master.gz"

CACHE_TTL_HOURS = 24

class SecIndex:
    def __init__(self, cache_dir: Path, user_agent: str = DEFAULT_UA):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        (self.cache_dir / "raw").mkdir(exist_ok=True)
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": user_agent, "Accept-Encoding": "gzip, deflate"})

    # --------------- Public API ---------------

    def refresh_json_cache(self, use_master: bool = False, years_back: int = 5, force: bool = False):
        """
        Refresh caches. If use_master=True, also aggregate quarterly master.gz for the last `years_back` years.
        """
        ticker_json = self.cache_dir / "ticker_map.json"
        names_json  = self.cache_dir / "name_to_ciks.json"

        # Ticker map: always refresh on TTL or force
        if force or not self._is_fresh(ticker_json):
            tmap = self._fetch_ticker_map()
            self._write_json(ticker_json, {"fetched_at": self._now_iso(), "map": tmap})

        # Name→CIKs: use cik-lookup-data.txt as primary
        if force or not self._is_fresh(names_json):
            name_map = self._fetch_name_map_from_cik_lookup()
            if use_master:
                # augment with quarterly master.gz
                add_map = self._augment_with_master(years_back=years_back)
                # merge (preserve all CIKs; avoid dup cik per name)
                for nm, ciks in add_map.items():
                    dest = name_map.setdefault(nm, [])
                    seen = set(dest)
                    for c in ciks:
                        if c not in seen:
                            dest.append(c); seen.add(c)
            payload = {"fetched_at": self._now_iso(), "count": len(name_map), "map": name_map}
            self._write_json(names_json, payload)

        return ticker_json, names_json

    def load_from_cache(self):
        ticker_json = self.cache_dir / "ticker_map.json"
        names_json  = self.cache_dir / "name_to_ciks.json"
        t = json.loads(ticker_json.read_text())
        n = json.loads(names_json.read_text())
        return t["map"], n["map"], t.get("fetched_at",""), n.get("fetched_at",""), n.get("count", len(n.get("map", {})))

    # --------------- Internals ---------------

    def _is_fresh(self, path: Path) -> bool:
        if not path.exists():
            return False
        mtime = datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc)
        return (datetime.now(timezone.utc) - mtime) < timedelta(hours=CACHE_TTL_HOURS)

    def _now_iso(self) -> str:
        return datetime.now(timezone.utc).isoformat()

    def _write_json(self, path: Path, obj):
        path.write_text(json.dumps(obj, indent=2))

    def _get(self, url: str, timeout: int = 120) -> requests.Response:
        r = self.session.get(url, timeout=timeout)
        r.raise_for_status()
        return r

    def _fetch_ticker_map(self) -> Dict[str, str]:
        r = self._get(URL_COMPANY_TICKERS, timeout=60)
        data = r.json()
        out: Dict[str, str] = {}
        for v in data.values():
            try:
                ticker = v["ticker"].upper()
                cik10  = f'{int(v["cik_str"]):010d}'
                out[ticker] = cik10
            except Exception:
                continue
        return out

    def _fetch_name_map_from_cik_lookup(self) -> Dict[str, List[str]]:
        """
        Parse /Archives/edgar/cik-lookup-data.txt which is lines of "CIK|Company Name".
        """
        r = self._get(URL_CIK_NAME_TXT, timeout=180)
        out: Dict[str, List[str]] = {}
        for line in r.text.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split("|")
            if len(parts) < 2:
                continue
            cik_raw, name_raw = parts[0].strip(), parts[1].strip()
            try:
                cik10 = f"{int(cik_raw):010d}"
            except Exception:
                continue
            nm = normalize_company_name(name_raw)
            if not nm:
                continue
            out.setdefault(nm, []).append(cik10)
        return out

    def _augment_with_master(self, years_back: int = 5) -> Dict[str, List[str]]:
        """
        Aggregate name→CIKs from quarterly master.gz across recent years.
        """
        now = datetime.now(timezone.utc)
        start_year = now.year - max(0, int(years_back)) + 1  # inclusive
        agg: Dict[str, List[str]] = {}
        for year in range(start_year, now.year + 1):
            for q in (1,2,3,4):
                url = URL_MASTER_INDEX_TPL.format(year=year, q=q)
                try:
                    gz = self._get(url, timeout=180).content
                except Exception:
                    continue  # skip missing quarters politely
                try:
                    with gzip.GzipFile(fileobj=io.BytesIO(gz)) as zf:
                        text = zf.read().decode("latin-1", errors="ignore")
                except Exception:
                    continue
                # Skip header; lines after a blank line are data
                lines = text.splitlines()
                # Find the header terminator (line starting with "-----")
                try:
                    start_idx = next(i for i, ln in enumerate(lines) if ln.startswith("-----"))
                    data_lines = lines[start_idx+1:]
                except StopIteration:
                    data_lines = lines
                for ln in data_lines:
                    parts = ln.split("|")
                    if len(parts) < 2:
                        continue
                    cik_raw, name_raw = parts[0].strip(), parts[1].strip()
                    try:
                        cik10 = f"{int(cik_raw):010d}"
                    except Exception:
                        continue
                    nm = normalize_company_name(name_raw)
                    if not nm:
                        continue
                    dest = agg.setdefault(nm, [])
                    if cik10 not in dest:
                        dest.append(cik10)
        return agg