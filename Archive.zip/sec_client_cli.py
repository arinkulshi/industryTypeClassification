# sec_client_cli.py
import argparse
import json
from pathlib import Path

from sec_client import SecClient

def load_ticker_map(path: str) -> dict:
    j = json.loads(Path(path).read_text())
    # Accept either {"map": {...}} or raw dict
    return j.get("map", j)

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--user-agent", required=True, help="Real UA with contact info (SEC requirement)")
    p.add_argument("--cik", help="10-digit CIK (with or without leading zeros)")
    p.add_argument("--ticker", help="Ticker symbol (requires --ticker-json)")
    p.add_argument("--ticker-json", help="Path to ticker_map.json (Chunk 2)")
    p.add_argument("--dump", help="Write raw submissions JSON to this file")
    args = p.parse_args()

    if not args.cik and not args.ticker:
        p.error("Provide --cik or --ticker (with --ticker-json).")

    cik = None
    if args.ticker:
        if not args.ticker_json:
            p.error("--ticker-json is required when using --ticker.")
        tmap = load_ticker_map(args.ticker_json)
        upper = args.ticker.upper()
        if upper not in tmap:
            p.error(f"Ticker {upper} not found in ticker map.")
        cik = tmap[upper]
    else:
        cik = args.cik

    client = SecClient(user_agent=args.user_agent)
    sub = client.get_submissions(cik)

    if sub is None:
        print("No submissions found (404).")
        return

    # Minimal summary to confirm success
    filings = sub.get("filings", {}).get("recent", {})
    forms = filings.get("form", [])[:5]
    sic = sub.get("sic")
    sic_desc = sub.get("sicDescription")
    entity = sub.get("name", "<unknown>")
    print(json.dumps({
        "entity": entity,
        "sic": sic,
        "sicDescription": sic_desc,
        "recentForms": forms
    }, indent=2))

    if args.dump:
        Path(args.dump).write_text(json.dumps(sub, indent=2))
        print(f"Wrote {args.dump}")

if __name__ == "__main__":
    main()
