# resolution.py (patched)
from __future__ import annotations
from typing import List, Dict, Any, Optional
import math

from candidate_generation import generate_candidates
from scoring import rank_candidates

def _zip_score_of(rc: Dict[str, Any], zip5: str) -> int:
    mz = (rc.get("matched_zip") or "").strip()
    return int(bool(zip5) and mz == zip5)

def _city_score_of(rc: Dict[str, Any], zip5: str) -> float:
    # city_score = addr_score - zip_score
    addr = float(rc.get("addr_score", 0.0))
    return max(0.0, addr - (_zip_score_of(rc, zip5)))

def resolve_cik(
    ranked_candidates: List[Dict[str, Any]],
    zip5: str,
    min_accept: float = 1.4,   # ↓ from 1.6
    gap_accept: float = 0.25,  # ↓ from 0.3
    keep_top: int = 3,
) -> Dict[str, Any]:
    ranked = ranked_candidates or []
    if not ranked:
        return {"status": "not_found", "reason": "no candidates", "top_candidates": []}

    top1 = ranked[0]
    t1 = float(top1.get("total_score", 0.0))
    a1 = float(top1.get("addr_score", 0.0))
    z1 = _zip_score_of(top1, zip5)

    if t1 >= min_accept:
        return {"status": "ok", "cik10": top1["cik10"], "reason": f"top1.total_score={t1:.2f} >= {min_accept}", "top_candidates": ranked[:keep_top]}

    top2 = ranked[1] if len(ranked) > 1 else None
    gap = (t1 - float(top2.get("total_score", 0.0))) if top2 else math.inf
    z2 = _zip_score_of(top2, zip5) if top2 else 0

    if gap >= gap_accept and a1 >= 1.0:
        return {"status": "ok", "cik10": top1["cik10"], "reason": f"gap {gap:.2f} >= {gap_accept} and addr_score {a1:.2f} >= 1.0", "top_candidates": ranked[:keep_top]}

    # New Rule 4: exact ZIP + decent city match (>=0.6)
    if z1 == 1 and _city_score_of(top1, zip5) >= 0.6:
        return {"status": "ok", "cik10": top1["cik10"], "reason": "exact ZIP and city match ≥ 0.6", "top_candidates": ranked[:keep_top]}

    if z1 == 1 and z2 == 0:
        return {"status": "ok", "cik10": top1["cik10"], "reason": "top1 has exact ZIP; top2 does not", "top_candidates": ranked[:keep_top]}

    return {"status": "ambiguous", "reason": "scores too close or insufficient address evidence", "top_candidates": ranked[:keep_top]}

def resolve_from_name(
    name: str, city: str, zip5: str, name_map: Dict[str, List[str]], client,
    threshold: float = 0.85, limit: int = 10, min_accept: float = 1.4, gap_accept: float = 0.25, keep_top: int = 3,
) -> Dict[str, Any]:
    cands = generate_candidates(name, name_map, threshold=threshold, limit=limit)
    ranked = rank_candidates(cands, city, zip5, client=client, limit=limit)
    out = resolve_cik(ranked, zip5, min_accept=min_accept, gap_accept=gap_accept, keep_top=keep_top)
    out["query"] = {"name": name, "city": city, "zip5": zip5}
    return out
