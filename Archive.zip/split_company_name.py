import pandas as pd

df = pd.read_csv("company_names_normalized.csv")

# Split into separate columns
df[['Company Name', 'city', 'zip']] = df['Company Name,city,Zip Code'].str.split(",", expand=True)

# Save corrected CSV
df.to_csv("company_names_normalized_fixed.csv", index=False)